Friends of pygit2:

- [Iterative](https://iterative.ai/)

Add your name to the list,
[become a friend of pygit2](https://github.com/sponsors/jdavid).

Past sponsors:

- [SourceHut](https://sourcehut.org)
- [omniproc](https://github.com/omniproc)
