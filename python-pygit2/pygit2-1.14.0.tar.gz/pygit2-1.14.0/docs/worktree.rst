**********************************************************************
Worktrees
**********************************************************************

.. automethod:: pygit2.Repository.add_worktree
.. automethod:: pygit2.Repository.list_worktrees
.. automethod:: pygit2.Repository.lookup_worktree

.. autoclass:: pygit2.Worktree
   :members:
