---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: enhancement
assignees: ''

---

<!-- Remove the comments below and adapt it to your needs  -->

# Situation
<!-- A clear and concise description of what the feature is. 
Ex. I'm always frustrated when [...]
-->

# Possible Solution/Idea
<!-- A clear and concise description of what you want to happen. 
A clear and concise description of any alternative solutions or features you've considered.
-->


# Additional context
<!-- Add any other context about the feature request here. -->
