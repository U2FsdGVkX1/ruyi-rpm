Advanced topics
===============


.. toctree::
    :maxdepth: 1

    deal-with-invalid-versions
    create-subclasses-from-version
    display-deprecation-warnings
    combine-pydantic-and-semver
    convert-pypi-to-semver
    version-from-file
