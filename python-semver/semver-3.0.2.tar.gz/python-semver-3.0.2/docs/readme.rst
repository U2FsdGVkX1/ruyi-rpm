If you are searching for how to stay compatible
with semver3, refer to :ref:`semver2-to-3`.

.. include:: ../README.rst
