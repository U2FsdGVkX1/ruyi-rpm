Please also consult [the official documentation site](https://ruyisdk.org/docs/intro) for usage instructions.
The binaries [are also available](@RELEASE_MIRROR_URL@) at the RuyiSDK mirror site.

NOTE: You'll have to rename the downloaded binary to exactly `ruyi` before using.
